## System

* Version: <!-- geckodriver version -->
* Platform: <!-- e.g. Linux/macOS/Windows + version -->
* Firefox: <!-- from the about dialogue -->
* Selenium: <!-- client + version -->


## Testcase

<!--
Please provide a minimal HTML document which permits the problem
to be reproduced.
-->


## Stacktrace

<!--
Error and stacktrace produced by client.
-->


## Trace-level log

<!--
See https://searchfox.org/mozilla-central/source/testing/geckodriver/doc/TraceLogs.md
for how to produce a trace-level log.

For trace logs with more than 20 lines please add its contents as attachment.
-->
